#include <iostream>
// You can add more C++ code here for the backend logic if needed
int main() {
    std::cout << "Content-Type: text/html\n\n";
    std::cout << "<!DOCTYPE html>\n";
    std::cout << "<html>\n";
    std::cout << "<head>\n";
    std::cout << "<title>Todo List Manager</title>\n";
    std::cout << "</head>\n";
    std::cout << "<body>\n";
    std::cout << "<h1>Todo List Manager</h1>\n";
    std::cout << "<p>Todo list functionality is implemented in the HTML code.</p>\n";
    std::cout << "</body>\n";
    std::cout << "</html>\n";
    return 0;
}
